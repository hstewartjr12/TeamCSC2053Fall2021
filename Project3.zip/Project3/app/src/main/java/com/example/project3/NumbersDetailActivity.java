package com.example.project3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.EditText;

import java.util.LinkedList;

public class NumbersDetailActivity extends AppCompatActivity {
    private final LinkedList<Integer> mNumbers = new LinkedList<>();
    private RecyclerView mRecyclerView;
    private NumbersAdapter mAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_numbersdetail);

        // these are what's creating the problem
        int limit1 = Integer.parseInt(findViewById(R.id.numberInput1).toString());
        int limit2 = Integer.parseInt(findViewById(R.id.numberInput2).toString());

        /*
        for (int i = limit1; i <= limit2; i++) {
            mNumbers.add(i + "");
        }
        */


        for (int i = 0; i <= 20; i++) {
            mNumbers.add(i);
        }


        mRecyclerView = findViewById(R.id.recyclerView);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mAdapter = new NumbersAdapter(this, mNumbers);
        mRecyclerView.setAdapter(mAdapter);
    }
}